<?php include 'header.php'?>

<div class="subpage-head has-margin-bottom">
<div class="container">
<h3>Contact us</h3>
<p class="lead">Our Church address and contact details</p>
</div>
</div>

<div class="container">
<div class="row">
<div class="col-md-6 has-margin-bottom">
<form id="form1" role="form">
<div class="form-group">

	 <div id="mms"></div>
<label>Full Name</label>
<input type="text" class="form-control" name="name" id="name">
</div>
<div class="form-group">
<label>Email ID</label>
<input type="email" class="form-control" name="email" id="email">
</div>
<div class="form-group">
<label>Phone</label>
<input type="text" class="form-control" name="mobile" id="mobile">
</div>
<div class="form-group">
<label>Message</label>
<textarea class="form-control" rows="5" name="message" id="message"></textarea>
</div>
<button type="submit" class="btn btn-primary btn-lg">Send message</button>
<span class="help-block loading"></span>
</form>
</div>

<div class="col-md-6 has-margin-bottom">
<h5>OUR ADDRESS</h5>
<div class="row">
<div class="col-lg-6">Catholic Church<br>
121 King Street,	Melbourne <br>
Victoria 3000 Australia</div>
<div class="col-lg-6">Phone: +61 3 8376 6284<br>
Fax: +61 38 376 6284<br>
Email: <a href="#"><span class="__cf_email__" data-cfemail="dab7bbb3b69ab9bbaeb2b5b6b3b9adbfb8a9b3aebff4b9b5b7">[email&#160;protected]</span></a></div>
</div>
<hr>
<h5>ANOTHER ADDRESS</h5>
<div class="row">
<div class="col-lg-6">Catholic Church<br>
121 King Street, Melbourne <br>
Victoria 3000 Australia</div>
<div class="col-lg-6">Phone: +61 3 8376 6284<br>
Fax: +61 38 376 6284<br>
Email: <a href="#"><span class="__cf_email__" data-cfemail="204d41494c60434154484f4c4943574542534954450e434f4d">[email&#160;protected]</span></a></div>
</div>
</div>
</div>
</div>


 <script>

 $(document).ready(function () {
 //alert("hai"); 
  $("#form1").validate({
        rules: {
             "name": {
                required: true,
              },
            
          "email": {required: true},
          "mobile": {required: true},

             /*here remote functions*/
          /* "email": {required: true,email:true, 
                             remote: {
                           type: 'post',
                url: '<?php echo base_url();?>index.php/logcon2/checkmail',
                    data: {'email':function(){return $('#email').val();}
                    },
                                }},*/
          "message": {required: true}
          
      },
        
        messages: {
            
            "name": {
                required: "Please, enter a user name",
             minlength: "minimum should be 5 characters"
            },
      
             "email": {required:"Please Enter your password"},
             /*here remote function*/
            /* "email": {required:"Please Enter your password",remote: "That email is already Registered"},*/
  
             "mobile": {required:"Please Enter your password"}
                
         }
         
    });
  });

 $("form#form1").submit(function(e) {
  
 e.preventDefault();


	var formdata= new FormData(this);
    var isvalid= $("#form1").valid();
 
alert(isvalid);exit;

  if(isvalid){



  $.ajax({
   
   
   url:"",
   type:"POST",
   data:formdata,
   success: function(data){
    
  //alert(data);exit;
    
    if($.trim(data)=='Successfull')
     
             {
  //alert("haiiii");
             	$("#mms").show();
              $('#mms').fadeIn().html(data);
					
              setTimeout(function() {
                              
					$('#mms').fadeOut("slow");
				}, 2000 );
              
                setTimeout(function(){
               
                 window.location.href="<?php echo base_url(); ?>index.php/logcon2/loggin";
                 //location.reload();
                 
                },1000);
             
             }
     
   // alert(data);exit;
   },
   cache: false,
   contentType: false,
   processData: false
   

  });

}	
}); 
    

  
  </script>

  

<!-- <div class="location-map">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1575.9186034720387!2d144.95541222452604!3d-37.817281929786624!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642c9a8d8495f%3A0xedc33f230d1355b1!2sEnvato+Pty+Ltd!5e0!3m2!1sen!2sin!4v1407063773571" height="260"></iframe>
</div>
 -->

<?php include 'footer.php'?>