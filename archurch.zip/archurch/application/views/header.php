<!DOCTYPE html>
<html lang="en">


<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Our Church is a premium HTML5 Church Website Template with Responsive design. Church Template includes many pages like Bulletin, Programs, events, sermons, ministries, working church contact form etc..">
<meta name="keywords" content="Church, Website, Template, Bulletin, Programs, Events, Themeforest, Premium, Charity, Non Profit ">
<meta name="author" content="Surjith SM">
<title>Archurch</title>

<script src="../../cdn-cgi/apps/head/-mEFVS8y7qx5pVzWHQTCQu5gnVM.js"></script>


<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">

<link href="<?php echo base_url();?>css/church.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/fancybox.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/flexslider.css" rel="stylesheet">

<script src="<?php echo base_url();?>js/jquery.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.form-validator.min.js"></script>
   <script src="<?php echo base_url();?>js/jquery.validate.js" type="text/javascript"></script>





<link rel="shortcut icon" href="images/favicon.png">

<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Droid+Serif:400,700' rel='stylesheet' type='text/css'>
</head>
<body>

<div class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
<a class="navbar-brand" href="index.html"> <img src="<?php echo base_url();?>images//church-logo.png" alt="church logo" class="img-responsive"></a> 
</div>
<div class="navbar-collapse collapse ">
<ul class="nav navbar-nav navbar-right">
<li class="dropdown active"><a href="<?php echo base_url();?>index.php/Arcon/indexani">HOME <span class=""></span></a>
<!-- <ul class="dropdown-menu dropdown-menu-left" role="menu">
<li><a href="index.html">Home Default</a></li>
<li><a href=''>Home Animated Slider</a></li>
</ul> -->
</li>
<li><a href="<?php echo base_url();?>index.php/Arcon/about">ABOUT US</a></li>

<li> <a href="<?php echo base_url();?>index.php/Arcon/imagegal">IMAGE GALLERY <span class=""></span></a>
<!-- <ul class="dropdown-menu dropdown-menu-left" role="menu">
<li><a href="ministry.html">Childrens Ministry</a></li>
<li><a href="ministry.html">Students Ministry</a></li>
<li><a href="ministry.html">Groups</a></li>
</ul> -->
</li>
<li> <a href="<?php echo base_url();?>index.php/Arcon/video">VIDEO GALLERY <span class=""></span></a>
<!-- <ul class="dropdown-menu dropdown-menu-left" role="menu">
<li><a href="sermons.html">Christ-Occupied</a></li>
<li><a href="sermons.html">God's Love</a></li>
<li><a href="sermons.html">Faithfulness</a></li>
<li><a href="sermons.html">Praise Him</a></li>
</ul> -->
</li>
<!-- li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">PAGES <span class="caret"></span></a>
<ul class="dropdown-menu dropdown-menu-left" role="menu">
<li><a href="image-gallery.html">Image Gallery</a></li>
<li><a href="video-gallery.html">Video Gallery</a></li>
<li><a href="blog.html">Blog list</a></li>
<li><a href="blog-single.html">Blog Single</a></li>
<li><a href="events-programs.html">Events &amp; Programs</a></li>
<li><a href="event-single.html">Event Single</a></li>
<li><a href="event-calendar.html">Event Calendar</a></li>
<li><a href="charity-donation.html">Charity &amp; Donations</a></li>
<li class="divider"></li>
<li class="dropdown-header">OTHER PAGES</li>
<li><a href="prayers.html">Prayers</a></li>
<li><a href="faq.html">FAQ</a></li>
<li><a href="shortcodes.html">Shortcodes</a></li>
<li><a href="full-width.html">Full Width</a></li>
<li><a href="left-sidebar.html">Left Sidebar</a></li>
<li><a href="http://bit.ly/BuyCatholic">Buy this Template</a></li>
</ul>
</li> -->
<li><a href="<?php echo base_url();?>index.php/Arcon/contact">CONTACT US</a></li>
</ul>
</div>

</div>
</div>
