<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Arcon extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}


	public function indexani()
	{
		$this->load->view('indexanimated');
	}

	public function about()
	{
		$this->load->view('about');
	}

	public function imagegal()
	{
		$this->load->view('image-gallery');
	}

	public function video()
	{
		$this->load->view('video-gallery');
	}

	public function contact()
	{
		$this->load->view('contact');
	}
}
